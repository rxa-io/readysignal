creds = {'access_token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjQ2MDJmYTk0ZDZmMDFjMmQzNmNjYmE5NmIwNzE4ODZlMTM5'
                         'Mzc2ZmZkMzU2ZWIzMWJmOTcyMjgyYjYxNTg5MTRhZjQ5ZTc1NGQzYWE3NjliIn0.eyJhdWQiOiI1IiwianRpIjoiNDYw'
                         'MmZhOTRkNmYwMWMyZDM2Y2NiYTk2YjA3MTg4NmUxMzkzNzZmZmQzNTZlYjMxYmY5NzIyODJiNjE1ODkxNGFmNDllNzU0'
                         'ZDNhYTc2OWIiLCJpYXQiOjE1OTU1MTMwMTAsIm5iZiI6MTU5NTUxMzAxMCwiZXhwIjoxNTk4MTA1MDEwLCJzdWIiOiI1'
                         'Iiwic2NvcGVzIjpbXX0.SDLBqD3PM__pWLZ0mbYH0Qv6TY0PuDqGTd64hR-AC8EjLavYrrVFkzSL22YLcocvVxNPWVrB'
                         '6Cu7sgJLhzzgGWD-aXDS1wfNXnOQt8XaPNMc92zdure0zGuhrBfu3Wu8uymWCPOowFX9faCBtunP2kslritX2efVKtED'
                         'Zyk1CiF95GatYfXlf9Og4C6-vBxc4Gi_dcWyuRsT8Ddd6S89E5qqpW0V_gGaE0zZBvE0oMpMy2BvrgHo17hElSvZ4szX'
                         'YrpGcCMXoTFtYD8SexoomiLb_5AtYAlKX7x_lyGyw7VH5PxK_xH_DxB_tQN_ArjvGf5GxbbPHS4mtLzHOoSo1cqs-Zs8'
                         'lvbjQE3h8A5gb3YtTDQEkGIoyAFVpN0aL3vtWncSk1uFBpT0M-GY4WUnLDuQct_GuvnBoakpQUKTjS8q96BKp19Za5F1'
                         'PrKYl9uKidTDc5WtAq6taQpKrKOBdAmj94_7kaXscz53NwswokWTIrQ72WdlRQH8NH-eebDv_nBJjQHkxOoUOSc3CWBK'
                         'EYZWDuJ1w3unWmcsHulZxEblDWCIo8ldNSUmBBtZSbk5FargJ1Ro7y30iHJV9SRtPbBbQHPev1pMwIBrFlpK-89uNHdH'
                         'hwc7tLextzFSba5W8og3uku_U9tJSl8s6Ap-h7cRvmB_KfsNKG805OzB3cM',
         'signal_id': 7
         }

